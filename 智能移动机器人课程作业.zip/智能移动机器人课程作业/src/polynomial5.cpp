#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <vector>
#include <Eigen/Dense>
#include <iostream>

class TrajectoryGenerator {
public:
    TrajectoryGenerator() : path_sub_(nh_.subscribe("path", 1, &TrajectoryGenerator::pathCallback, this)),
                            optimized_path_pub_(nh_.advertise<nav_msgs::Path>("optimized_path", 1)) {}

    void pathCallback(const nav_msgs::Path::ConstPtr& path_msg) {
        if (path_msg->poses.empty()) {
            return;
        }

        // 记录优化开始时间
        ros::Time start_time = ros::Time::now();

        // 提取路径点
        std::vector<Eigen::Vector2d> path_points;
        for (const auto& pose : path_msg->poses) {
            path_points.emplace_back(pose.pose.position.x, pose.pose.position.y);
        }

        // 进行轨迹优化（五次多项式拟合）
        std::vector<Eigen::Vector2d> optimized_path = optimizePath(path_points);

        // 记录优化结束时间
        ros::Time end_time = ros::Time::now();

        // 计算优化时间
        double optimization_time = (end_time - start_time).toSec();
        ROS_INFO("Trajectory optimization time: %.6f seconds", optimization_time);

        // 生成优化后的路径消息
        nav_msgs::Path optimized_path_msg;
        optimized_path_msg.header = path_msg->header;
        for (const auto& point : optimized_path) {
            geometry_msgs::PoseStamped pose;
            pose.pose.position.x = point.x();
            pose.pose.position.y = point.y();
            pose.pose.position.z = 0.0;
            optimized_path_msg.poses.push_back(pose);
        }

        // 发布优化后的路径
        optimized_path_pub_.publish(optimized_path_msg);
    }

private:
    // 轨迹优化函数（五次多项式拟合）
    std::vector<Eigen::Vector2d> optimizePath(const std::vector<Eigen::Vector2d>& path_points) {
        std::vector<Eigen::Vector2d> optimized_path;

        // 如果路径点少于2个，直接返回原始路径
        if (path_points.size() < 2) {
            return path_points;
        }

        // 使用五次多项式拟合
        int n = path_points.size();
        Eigen::MatrixXd A(n, 6);
        Eigen::VectorXd b_x(n);
        Eigen::VectorXd b_y(n);

        // 构建矩阵 A 和向量 b
        for (int i = 0; i < n; ++i) {
            double t = i;
            A(i, 0) = t * t * t * t * t;
            A(i, 1) = t * t * t * t;
            A(i, 2) = t * t * t;
            A(i, 3) = t * t;
            A(i, 4) = t;
            A(i, 5) = 1.0;
            b_x(i) = path_points[i].x();
            b_y(i) = path_points[i].y();
        }

        // 求解多项式系数
        Eigen::VectorXd coeffs_x = A.colPivHouseholderQr().solve(b_x);
        Eigen::VectorXd coeffs_y = A.colPivHouseholderQr().solve(b_y);

        // 生成优化后的路径点
        double step = 0.1; // 步长，控制优化后路径的密度
        for (double t = 0; t < n; t += step) {
            double x = coeffs_x(0) * t * t * t * t * t + coeffs_x(1) * t * t * t * t + coeffs_x(2) * t * t * t + coeffs_x(3) * t * t + coeffs_x(4) * t + coeffs_x(5);
            double y = coeffs_y(0) * t * t * t * t * t + coeffs_y(1) * t * t * t * t + coeffs_y(2) * t * t * t + coeffs_y(3) * t * t + coeffs_y(4) * t + coeffs_y(5);
            optimized_path.emplace_back(x, y);
        }

        return optimized_path;
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber path_sub_;
    ros::Publisher optimized_path_pub_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "trajectory_generator");
    TrajectoryGenerator trajectory_generator;
    ros::spin();
    return 0;
}

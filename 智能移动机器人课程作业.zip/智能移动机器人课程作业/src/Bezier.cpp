#include <iostream>
#include <vector>
#include <Eigen/Dense>
#include <cmath>
#include <ros/ros.h>
#include "nav_msgs/Path.h"
#include <geometry_msgs/PoseStamped.h>
#include <time.h>

// 定义路径格式
typedef std::vector<Eigen::Vector2d> Path;

// Step 4: 自行实现轨迹生成类
class TrajectoryGenerator
{
public:
    TrajectoryGenerator() = default;

    // 生成贝塞尔曲线轨迹
    nav_msgs::Path generateBezierTrajectory(const Path &path, double dt)
    {
        nav_msgs::Path trajectory;
        trajectory.header.frame_id = "map";
        trajectory.header.stamp = ros::Time::now();

        // 如果路径点少于3个，直接返回原始路径
        if (path.size() < 3)
        {
            for (const auto &point : path)
            {
                geometry_msgs::PoseStamped pose;
                pose.pose.position.x = point.x();
                pose.pose.position.y = point.y();
                pose.pose.position.z = 0.0;
                trajectory.poses.push_back(pose);
            }
            return trajectory;
        }

        // 生成贝塞尔曲线轨迹
        for (double t = 0; t <= 1.0; t += dt)
        {
            Eigen::Vector2d point = bezierPoint(path, t);
            geometry_msgs::PoseStamped pose;
            pose.pose.position.x = point.x();
            pose.pose.position.y = point.y();
            pose.pose.position.z = 0.0;
            trajectory.poses.push_back(pose);
        }

        // for (const auto& point : path) {
        //     geometry_msgs::PoseStamped pose;
        //     pose.pose.position.x = point.x();
        //     pose.pose.position.y = point.y();
        //     pose.pose.position.z = 0.0;
        //     trajectory.poses.push_back(pose);
        // }

        return trajectory;
    }

private:
    // 计算贝塞尔曲线上的点
    Eigen::Vector2d bezierPoint(const Path &control_points, double t)
    {
        int n = control_points.size() - 1;
        Eigen::Vector2d point = Eigen::Vector2d::Zero();

        // 使用动态规划计算二项式系数
        std::vector<std::vector<double>> binomial_coeff(n + 1, std::vector<double>(n + 1, 0));
        for (int i = 0; i <= n; ++i)
        {
            binomial_coeff[i][0] = 1;
            binomial_coeff[i][i] = 1;
            for (int j = 1; j < i; ++j)
            {
                binomial_coeff[i][j] = binomial_coeff[i - 1][j - 1] + binomial_coeff[i - 1][j];
            }
        }

        for (int i = 0; i <= n; ++i)
        {
            double blend = binomial_coeff[n][i] * std::pow(t, i) * std::pow(1 - t, n - i);
            point += blend * control_points[i];
        }

        return point;
    }

    // // 计算贝塞尔曲线上的点
    // Eigen::Vector2d bezierPoint(const Path& control_points, double t) {
    //     int n = control_points.size() - 1;
    //     Eigen::Vector2d point = Eigen::Vector2d::Zero();

    //     for (int i = 0; i <= n; ++i) {
    //         double binomial_coeff = binomialCoefficient(n, i);
    //         double blend = binomial_coeff * std::pow(t, i) * std::pow(1 - t, n - i);
    //         point += blend * control_points[i];
    //     }

    //     return point;
    // }

    // // 计算二项式系数 C(n, k)
    // double binomialCoefficient(int n, int k) {
    //     if (k == 0 || k == n) return 1;
    //     return binomialCoefficient(n - 1, k - 1) + binomialCoefficient(n - 1, k);
    // }
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "trajectory");
    ros::NodeHandle nh;

    ros::Rate rate(10);
    ros::Publisher trajectory_pub = nh.advertise<nav_msgs::Path>("Bezier_optimized_trajectory", 1);
    // ros::Publisher trajectory_pub_1 = nh.advertise<nav_msgs::Path>("optimized_trajectory_1", 1);
    ros::Subscriber path_sub = nh.subscribe<nav_msgs::Path>("path", 1, [&](const nav_msgs::Path::ConstPtr &msg)
                                                            {
        Path path;
        for (const auto& pose : msg->poses) {
            path.emplace_back(pose.pose.position.x, pose.pose.position.y);
        }

        TrajectoryGenerator generator;
        clock_t start_time = clock();
        nav_msgs::Path trajectory = generator.generateBezierTrajectory(path, 0.01); // 每0.01秒一个点
        clock_t end_time = clock();
        
        // 计算运行时间（以秒为单位）
        double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
        // 输出运行时间
        printf("程序运行时间: %.6f 秒\n", elapsed_time);

        trajectory_pub.publish(trajectory);
        rate.sleep(); });

    ros::spin();
    return 0;
}